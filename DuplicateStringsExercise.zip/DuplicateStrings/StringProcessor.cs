﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DuplicateStrings
{
    public class StringProcessor
    {
        public string AnalyseMessage(string message)
        {
            var messageArray = ConvertMessage(message);
            var analysis = FindDuplicates(messageArray);
            return CreateOutputMessage(analysis);
        }

        internal string[] ConvertMessage(string message)
        {
            message = RemoveAnyPunctuation(message.ToLower());
            return message.Split(' ');
        }

        internal string RemoveAnyPunctuation(string message)
        {
            var sb = new StringBuilder();

            foreach (var c in message.Where(c => !char.IsPunctuation(c)))
            {
                sb.Append(c);
            }
            return  sb.ToString();
        }

        internal string CreateOutputMessage(Dictionary<string, int> analysis)
        {
            var results = new StringBuilder();

            foreach (var item in analysis)
            {
                results.Append(item.Key);
                results.Append(" - ");
                results.Append(item.Value);
                results.AppendLine();
            }

            return results.ToString();
        }

        internal Dictionary<string, int> FindDuplicates(string[] message)
        {
            var analysis = new Dictionary<string, int>(StringComparer.InvariantCultureIgnoreCase);

            foreach (var item in message)
            {
                int found;
                analysis.TryGetValue(item, out found);

                if (found <= 0)
                {
                    analysis[item] = 1;
                }
                else
                {
                    analysis[item]++;
                }
            }
            return analysis;
        }
    }
}
