﻿using System;
using DuplicateStrings;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            var stringProcessor = new StringProcessor();

            var results = stringProcessor.AnalyseMessage("This is a statement, and so is this.");

            Console.WriteLine(results);
            Console.ReadLine();
        }
    }
}
