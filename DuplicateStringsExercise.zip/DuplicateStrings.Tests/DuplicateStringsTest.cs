﻿using System.Collections.Generic;
using NUnit.Framework;

namespace DuplicateStrings.Tests
{
    [TestFixture]
    public class DuplicateStringsTest
    {
        private StringProcessor _stringProcessor;
        private string _testString;

        [SetUp]
        public void SetUp()
        {
            _stringProcessor = new StringProcessor();
            _testString = "This is a statement, and so is this.";
        }

        [Test]
        public void RemoveAnyPunctuation_GivenSimpleShortMessage_RemovesAllPunctuationFromString()
        {
            const string expectedString = "This is a statement and so is this";

            var converted = _stringProcessor.RemoveAnyPunctuation(_testString);

            Assert.AreEqual(converted, expectedString);
        }

        [Test]
        public void ConvertMessage_GivenSimpleShortMessage_ConvertsToStringArrayWithExpectedValuesRegardlessOfCase()
        {
            var expectedResult = new[] {"this","is","a","statement","and","so","is","this"};

            var stringProcessor = new StringProcessor();
            var result = stringProcessor.ConvertMessage(_testString);

            CollectionAssert.AreEquivalent(result, expectedResult);
        }

        [Test]
        public void FindDuplicates_GivenSimpleShortSentence_ReturnsExpectedWordCount()
        {
            var convertedMessage = new[] { "this", "is", "a", "statement", "and", "so", "is", "this" };

            var expectedDictionary = new Dictionary<string, int>
            {
                {"this", 2},
                {"is",2},
                {"a",1},
                {"statement",1},
                {"and",1},
                {"so",1}
            };

            var result = _stringProcessor.FindDuplicates(convertedMessage);

            CollectionAssert.AreEqual(expectedDictionary,result);
        }

        [Test]
        public void CreateOutputMessage_GivenExpectedAnalysis_ReturnsFormattedResults()
        {
            const string expectedOutput = "this - 2\r\nis - 2\r\na - 1\r\nstatement - 1\r\nand - 1\r\nso - 1\r\n";

            var analysis = new Dictionary<string, int>
            {
                {"this", 2},
                {"is",2},
                {"a",1},
                {"statement",1},
                {"and",1},
                {"so",1}
            };

            var result = _stringProcessor.CreateOutputMessage(analysis);

            Assert.AreEqual(result, expectedOutput);
        }
    }
}
